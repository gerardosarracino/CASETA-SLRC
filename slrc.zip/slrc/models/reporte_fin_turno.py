# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import logging
from datetime import timedelta
from functools import partial
import time
import psycopg2
import pytz

from odoo import api, fields, models, tools, _
from odoo.tools import float_is_zero
from odoo.exceptions import UserError
from odoo.http import request
from odoo.osv.expression import AND
import base64

_logger = logging.getLogger(__name__)


class PosReportesTurnoSrlc(models.TransientModel):
    _name = 'pos.reportes_turno.wizard'

    def _default_sesiones(self):
        sesion = self.env["pos.config"].search([])
        print(sesion, ' SESION ')
        x = ''
        if not sesion:
            pass
        else:
            for ss in sesion:
                datos = {
                    'pos_config_srlc_ids': [
                        [4, ss.id, {}]]}  # 'id': sesion.config_id.id, 'name': sesion.config_id.name
                x = self.update(datos)
            return x

    def _default_start_date(self):
        """ Find the earliest start_date of the latests sessions """
        # restrict to configs available to the user
        config_ids = self.env['pos.config'].search([]).ids
        # exclude configs has not been opened for 2 days
        self.env.cr.execute("""
            SELECT
            max(start_at) as start,
            config_id
            FROM pos_session
            WHERE config_id = ANY(%s)
            AND start_at > (NOW() - INTERVAL '2 DAYS')
            GROUP BY config_id
        """, (config_ids,))
        latest_start_dates = [res['start'] for res in self.env.cr.dictfetchall()]
        # earliest of the latest sessions
        return latest_start_dates and min(latest_start_dates) or fields.Datetime.now()

    start_date = fields.Datetime(required=True, default=_default_start_date)
    end_date = fields.Datetime(required=True, default=fields.Datetime.now)

    cajero = fields.Many2one('res.users',string="Cajero",) # default=_default_cajero
    jefe_operaciones = fields.Many2one('res.users',string="Jefe de Operaciones", required=False, )
    administrador = fields.Many2one('res.users',string="Administrador", required=False, )

    pos_config_srlc_ids = fields.Many2many('pos.config', compute="_default_sesiones") # default=lambda s: s.env['pos.config'].search([])

    tabla_cuotas = fields.Many2many('pos.tabla_emergentes')

    boleto_emergente = fields.Boolean(string="Activar Boletos Emergentes",  )

    total_dolares_matutino = fields.Float() # compute='_datos_reporte'

    def _datos_reporte(self, date_start=False, date_stop=False, config_ids=False, session_ids=False):
        fecha_hoy = fields.Datetime.now()
        hora = fecha_hoy.strftime("%H:%M:%S")
        if hora >= '00:00:00' and hora <= '07:59:59':
            turno = 'Matutino'
        elif hora >= '08:00:00' and hora <= '16:59:59':
            turno = 'Vespertino'
        elif hora >= '16:00:00' and hora <= '23:59:59':
            turno = 'Nocturno'

        report = self.env["pos.reportes_turno.wizard"].search([])[-1]
        for r in report:
            for i in r.pos_config_srlc_ids:
                sesion = self.env["pos.session"].search([('config_id.id', '=', i.id)]) # ,('stop_at', '!=', '')
                for s in sesion:
                    print(s.name, s.config_id.carril)
        self.total_dolares_matutino = 1

    def generate_report(self):

        '''sesion = self.env["pos.config"].search([])
        print(sesion, ' SESION ')'''

        fecha_hoy = fields.Datetime.now()
        hora = fecha_hoy.strftime("%H:%M:%S")

        fecha_dma2 = time.strftime("%d-%m-%Y", time.localtime())
        fecha_dma3 = time.strftime("%H:%M:%S", time.localtime())
        print(fecha_dma3)

        if hora >= '00:00:00' and hora <= '07:59:59':
            turno = 'Matutino'

            # BUSCAR LAS SESIONES QUE CORRESPONDAN A ESTE TURNO!

            buscar_sesiones_mat = self.env["pos.session"].search([('start_at', '>=', str(fecha_dma2) + ' 00:00:00'),
                                                                  ('stop_at', '<=', str(fecha_dma2) + ' 07:59:59')])
            print(buscar_sesiones_mat)

        if hora >= '08:00:00' and hora <= '16:59:59':
            turno = 'Vespertino'

            # BUSCAR LAS SESIONES QUE CORRESPONDAN A ESTE TURNO!

            buscar_sesiones_vesp = self.env["pos.session"].search([('start_at', '>=', str(fecha_dma2) + ' 08:00:00'),
                                                                  ('stop_at', '<=', str(fecha_dma2) + ' 16:59:59')])
            print(buscar_sesiones_vesp)

        if hora >= '16:00:00' and hora <= '23:59:59':
            turno = 'Nocturno'

            # BUSCAR TODAS LAS SESIONES POR SER EL ULTIMO TURNO
            buscar_sesiones_mat = self.env["pos.session"].search([('start_at', '>=', str(fecha_dma2) + ' 00:00:00'),
                                                                  ('stop_at', '<=', str(fecha_dma2) + ' 07:59:59')])
            buscar_sesiones_vesp = self.env["pos.session"].search([('start_at', '>=', str(fecha_dma2) + ' 08:00:00'),
                                                                   ('stop_at', '<=', str(fecha_dma2) + ' 16:59:59')])
            buscar_sesiones_noc = self.env["pos.session"].search([('start_at', '>=', str(fecha_dma2) + ' 16:00:00'),
                                                                  ('stop_at', '<=', str(fecha_dma2) + ' 23:59:59')])


            print('Matutino ' , buscar_sesiones_mat, '--- Vespertino ' , buscar_sesiones_vesp, '-- Nocturno: ', buscar_sesiones_noc)

            acum_pago_mat = 0
            cum_pagoiva_matutino = 0
            for mat in buscar_sesiones_mat:
                buscar_pagos = self.env["pos.payment"].search([('session_id', '=', mat.id)])

                for pagos in buscar_pagos:
                    cum_pagoiva_matutino += pagos.pos_order_id.amount_tax
                    acum_pago_mat += pagos.amount - pagos.pos_order_id.amount_tax

            cum_pagoiva_vespertino = 0
            acum_pago_vesp = 0
            for vesp in buscar_sesiones_vesp:
                buscar_pagos = self.env["pos.payment"].search([('session_id', '=', vesp.id)])

                for pagos in buscar_pagos:
                    cum_pagoiva_vespertino += pagos.pos_order_id.amount_tax
                    acum_pago_vesp += pagos.amount - pagos.pos_order_id.amount_tax

            acum_pago_nocturno = 0
            acum_pagoiva_nocturno = 0
            for noc in buscar_sesiones_noc:
                buscar_pagos = self.env["pos.payment"].search([('session_id', '=', noc.id)])

                for pagos in buscar_pagos:
                    acum_pagoiva_nocturno += pagos.pos_order_id.amount_tax
                    acum_pago_nocturno += pagos.amount - pagos.pos_order_id.amount_tax

        # BUSCAR COSTOS DE PEAJES
        motocicleta_cuota = ''
        auto_cuota = ''
        auto_1eje_cuota = ''
        auto_2eje_cuota = ''
        autobus_cuota = ''
        camion2je_cuota = ''
        camion3eje_cuota = ''
        camion4eje_cuota = ''
        buscar_peajes = self.env["product.template"].search([])
        for bp in buscar_peajes:
            if bp.name == 'MOTOCICLETA':
                motocicleta_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)
            elif bp.name == 'AUTO':
                auto_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)
            elif bp.name == 'AUTO + 1 EJE':
                auto_1eje_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)
            elif bp.name == 'AUTO + 2 EJE':
                auto_2eje_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)
            elif bp.name == 'AUTOBUS':
                autobus_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)
            elif bp.name == 'CAMION 2 EJES':
                camion2je_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)
            elif bp.name == 'CAMION 3 EJES':
                camion3eje_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)
            elif bp.name == 'CAMION 4 EJES':
                camion4eje_cuota = (float(bp.list_price) * (float(bp.taxes_id.amount)) / 100) + float(bp.list_price)

        print(turno, ' TURNO!')

        data = {'date_start': self.start_date,
                'date_stop': self.end_date,
                'config_ids': self.pos_config_srlc_ids.ids,

                # ACUMULADO DE CUOTAS
                'cuota_mn_mat': acum_pago_mat,
                'cuota_mn_vesp': acum_pago_vesp,
                'cuota_mn_nocturno': acum_pago_nocturno,
                'cuotaiva_mn_nocturno': acum_pagoiva_nocturno,
                'cuotaiva_mn_vespertino': cum_pagoiva_vespertino,
                'cuotaiva_mn_matutino': cum_pagoiva_matutino,

                # PEAJES
                'motocicleta_cuota': motocicleta_cuota,
                'auto_cuota': auto_cuota,
                'auto_1eje_cuota': auto_1eje_cuota,
                'auto_2eje_cuota': auto_2eje_cuota,
                'autobus_cuota': autobus_cuota,
                'camion2je_cuota': camion2je_cuota,
                'camion3eje_cuota': camion3eje_cuota,
                'camion4eje_cuota': camion4eje_cuota,

                }
        return self.env.ref('slrc.fin_turno_report_buttonx').report_action([], data=data)





