# SLRC

```bash
cd /opt
git clone -b dev git@github.com:Galartec/SLRC.git
ln -s /opt/SLRC/src/slrc /usr/lib/python3/dist-packages/odoo/addons/slrc
```